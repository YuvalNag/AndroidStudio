# CarRental (Android Application)

This project was realised for a course of Mobile and Distributed systems at Oxford Brookes university, it was required to create a distribued system using MPI (Message Passing Interface), with the libray OpenMPI. The server was to be run under a linux HAC cluster and the client interface was to be an android application.

This repository contains the android application (the client side project) of the system, the distributed system is located in this repository: https://github.com/AlexisChevalier/CarRental-Distributed-System.

If you have any question about the project design, a complete project report is available in the repository. For any other question please contact me directly or open an issue.
