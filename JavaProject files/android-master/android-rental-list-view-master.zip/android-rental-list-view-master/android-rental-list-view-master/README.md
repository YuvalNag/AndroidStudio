# Android Rental List View

This app sample illustrates how to create a basic list view with a customized array adapter. The layout includes an image on the left with text on the right. 
